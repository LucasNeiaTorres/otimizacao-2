#ifndef PARAMETROS_H
#define PARAMETROS_H

typedef struct parametros_t{
    int viabilidade;
    int otimalidade;
    int professor;
} parametros_t;

#endif